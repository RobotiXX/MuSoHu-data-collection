1. All parts are 3D printed with PLA material.
2. Camera mount is glued to the helmet using standard 'Epoxy Glue'.
3. Lidar mount is tight fit after tighting bolts.
4. Bolts used are M6x25 with flanged lock-nut.
5. Center mount for the velodyne is standard bolt as per the datasheet.

Note:- Might need to re-drill hole to size as 3D printing is not exactly accurate.